# Table Coverage Report

**Generated:** 2025-12-20 11:36:11

## A) Overall Coverage Summary

### Database-Level Stats

| Metric | Value | Notes |
|--------|-------|-------|
| Total databases | 146 | Unique databases in dataset |
| Total tables across all DBs | 793 | Sum of all tables |
| Tables used ≥1 time | 728 | 91.8% coverage |
| Tables never used | 65 | 8.2% unused |
| Avg tables per DB | 5.4 | — |
| Avg coverage per DB | 95.4% | Median: 100.0% |

## B) Table Usage Distribution

### B1) Usage Frequency

| Usage count | Tables | Share | Description |
|-------------|--------|-------|-------------|
| 0 (unused) | 65 | 8.2% | Never referenced |
| 1-2 times | 78 | 9.8% | Rarely used |
| 3-5 times | 97 | 12.2% | Occasionally used |
| 6-10 times | 168 | 21.2% | Regularly used |
| 11-20 times | 169 | 21.3% | Frequently used |
| 21-50 times | 167 | 21.1% | Very popular |
| 51+ times | 49 | 6.2% | Core tables |

## C) Per-Database Coverage

### C1) Coverage Ranking

**Best Coverage (Top 5):**

| Rank | Database | Tables | Used | Coverage | Queries |
|------|----------|--------|------|----------|---------|
| 1 | activity_1 | 5 | 5 | 100.0% | 88 |
| 2 | local_govt_in_alabama | 4 | 4 | 100.0% | 15 |
| 3 | insurance_fnol | 7 | 7 | 100.0% | 42 |
| 4 | store_1 | 11 | 11 | 100.0% | 112 |
| 5 | driving_school | 6 | 6 | 100.0% | 93 |

**Worst Coverage (Bottom 5):**

| Rank | Database | Tables | Used | Coverage | Queries | Unused Tables |
|------|----------|--------|------|----------|---------|---------------|
| 1 | solvency_ii | 12 | 2 | 16.7% | 15 | 10 |
| 2 | baseball_1 | 26 | 13 | 50.0% | 82 | 13 |
| 3 | tracking_software_problems | 6 | 4 | 66.7% | 48 | 2 |
| 4 | company_1 | 6 | 4 | 66.7% | 7 | 2 |
| 5 | soccer_1 | 6 | 4 | 66.7% | 14 | 2 |

## D) Unused Tables Analysis

### D1) Unused Tables by Database

*(showing databases with ≥3 unused tables)*

| Database | Unused Count | Examples | Possible Reasons |
|----------|-------------|----------|------------------|
| *Analysis requires schema introspection* | — | — | — |

*Note: Full unused table analysis requires schema introspection to identify all available tables.*

## H) Coverage Gaps & Recommendations

### H1) Critical Gaps

*(Databases with significant unused tables)*

| Database | Unused Count | Coverage | Impact | Recommendation |
|----------|-------------|----------|--------|----------------|
| solvency_ii | 10 | 16.7% | High | Add queries using: [addresses, agreements, assets, assets_in_events, channels, events, finances, locations, parties, parties_in_events] |
| baseball_1 | 13 | 50.0% | High | Add queries using: [appearances, batting, batting_postseason, fielding, fielding_outfield, fielding_postseason, manager, manager_award_vote, manager_half, pitching, pitching_postseason, player_award_vote, team_half] |
| soccer_1 | 2 | 66.7% | Medium | Add queries using: [team, team_attributes] |
| company_1 | 2 | 66.7% | Medium | Add queries using: [project, works_on] |
| tracking_software_problems | 2 | 66.7% | Medium | Add queries using: [problem_category_codes, problem_status_codes] |

### H2) Quick Wins

*(Databases needing coverage improvement)*

| Database | Current Coverage | Tables Used | Potential Improvement | Suggestion |
|----------|------------------|-------------|----------------------|------------|
| solvency_ii | 16.7% | 2/12 | 78.3% | Add queries for 10 unused tables |
| baseball_1 | 50.0% | 13/26 | 45.0% | Add queries for 13 unused tables |
| soccer_1 | 66.7% | 4/6 | 28.3% | Add queries for 2 unused tables |
| company_1 | 66.7% | 4/6 | 28.3% | Add queries for 2 unused tables |
| tracking_software_problems | 66.7% | 4/6 | 28.3% | Add queries for 2 unused tables |

### H3) Overall Recommendations

1. **🎯 Priority 1** (High Impact):
   - Analyze 146 databases for comprehensive table coverage
   - Identify unused tables across all databases
   - Focus on underused foreign key relationships

2. **🎯 Priority 2** (Medium Impact):
   - Balance query distribution across databases
   - Create queries using many-to-many join tables
   - Add temporal/historical queries for underused tables

3. **📊 Coverage Goals**:
   - Target: ≥90% table usage per database
   - Enable schema introspection for detailed analysis
   - Regular monitoring of table coverage metrics

## I) Table Coverage Heatmap

### Visual Summary

```
Database          Coverage  |████████████████████| Usage Pattern
──────────────────────────────────────────────────────────────────
activity_1         100% ████████████████████████ Perfect coverage
local_govt_in_alab 100% ████████████████████████ Perfect coverage
insurance_fnol     100% ████████████████████████ Perfect coverage
store_1            100% ████████████████████████ Perfect coverage
driving_school     100% ████████████████████████ Perfect coverage
device             100% ████████████████████████ Perfect coverage
csu_1              100% ████████████████████████ Perfect coverage
mountain_photos    100% ████████████████████████ Perfect coverage
movie_1            100% ████████████████████████ Perfect coverage
cinema             100% ████████████████████████ Perfect coverage
election           100% ████████████████████████ Perfect coverage
architecture       100% ████████████████████████ Perfect coverage
match_season       100% ████████████████████████ Perfect coverage
book_2             100% ████████████████████████ Perfect coverage
party_people       100% ████████████████████████ Perfect coverage
manufactory_1      100% ████████████████████████ Perfect coverage
climbing           100% ████████████████████████ Perfect coverage
loan_1             100% ████████████████████████ Perfect coverage
wrestler           100% ████████████████████████ Perfect coverage
scientist_1        100% ████████████████████████ Perfect coverage
allergy_1          100% ████████████████████████ Perfect coverage
flight_4           100% ████████████████████████ Perfect coverage
restaurant_1       100% ████████████████████████ Perfect coverage
perpetrator        100% ████████████████████████ Perfect coverage
wine_1             100% ████████████████████████ Perfect coverage
college_1          100% ████████████████████████ Perfect coverage
customer_complaint 100% ████████████████████████ Perfect coverage
hospital_1         100% ████████████████████████ Perfect coverage
network_2          100% ████████████████████████ Perfect coverage
game_1             100% ████████████████████████ Perfect coverage
student_assessment 100% ████████████████████████ Perfect coverage
apartment_rentals  100% ████████████████████████ Perfect coverage
pilot_record       100% ████████████████████████ Perfect coverage
gas_company        100% ████████████████████████ Perfect coverage
document_managemen 100% ████████████████████████ Perfect coverage
candidate_poll     100% ████████████████████████ Perfect coverage
riding_club        100% ████████████████████████ Perfect coverage
voter_2            100% ████████████████████████ Perfect coverage
election_represent 100% ████████████████████████ Perfect coverage
performance_attend 100% ████████████████████████ Perfect coverage
entertainment_awar 100% ████████████████████████ Perfect coverage
assets_maintenance 100% ████████████████████████ Perfect coverage
dorm_1             100% ████████████████████████ Perfect coverage
twitter_1          100% ████████████████████████ Perfect coverage
store_product      100% ████████████████████████ Perfect coverage
local_govt_mdm     100% ████████████████████████ Perfect coverage
gymnast            100% ████████████████████████ Perfect coverage
wedding            100% ████████████████████████ Perfect coverage
epinions_1         100% ████████████████████████ Perfect coverage
entrepreneur       100% ████████████████████████ Perfect coverage
film_rank          100% ████████████████████████ Perfect coverage
race_track         100% ████████████████████████ Perfect coverage
cre_Doc_Control_Sy 100% ████████████████████████ Perfect coverage
bike_1             100% ████████████████████████ Perfect coverage
yelp               100% ████████████████████████ Perfect coverage
product_catalog    100% ████████████████████████ Perfect coverage
debate             100% ████████████████████████ Perfect coverage
tracking_share_tra 100% ████████████████████████ Perfect coverage
manufacturer       100% ████████████████████████ Perfect coverage
ship_mission       100% ████████████████████████ Perfect coverage
shop_membership    100% ████████████████████████ Perfect coverage
icfp_1             100% ████████████████████████ Perfect coverage
medicine_enzyme_in 100% ████████████████████████ Perfect coverage
music_1            100% ████████████████████████ Perfect coverage
game_injury        100% ████████████████████████ Perfect coverage
school_bus         100% ████████████████████████ Perfect coverage
county_public_safe 100% ████████████████████████ Perfect coverage
department_store   100% ████████████████████████ Perfect coverage
journal_committee  100% ████████████████████████ Perfect coverage
roller_coaster     100% ████████████████████████ Perfect coverage
scholar            100% ████████████████████████ Perfect coverage
school_finance     100% ████████████████████████ Perfect coverage
swimming           100% ████████████████████████ Perfect coverage
body_builder       100% ████████████████████████ Perfect coverage
aircraft           100% ████████████████████████ Perfect coverage
college_3          100% ████████████████████████ Perfect coverage
student_1          100% ████████████████████████ Perfect coverage
music_2            100% ████████████████████████ Perfect coverage
restaurants        100% ████████████████████████ Perfect coverage
news_report        100% ████████████████████████ Perfect coverage
party_host         100% ████████████████████████ Perfect coverage
small_bank_1       100% ████████████████████████ Perfect coverage
products_for_hire  100% ████████████████████████ Perfect coverage
company_office     100% ████████████████████████ Perfect coverage
phone_market       100% ████████████████████████ Perfect coverage
decoration_competi 100% ████████████████████████ Perfect coverage
station_weather    100% ████████████████████████ Perfect coverage
theme_gallery      100% ████████████████████████ Perfect coverage
customers_and_addr 100% ████████████████████████ Perfect coverage
browser_web        100% ████████████████████████ Perfect coverage
insurance_policies 100% ████████████████████████ Perfect coverage
club_1             100% ████████████████████████ Perfect coverage
department_managem 100% ████████████████████████ Perfect coverage
train_station      100% ████████████████████████ Perfect coverage
culture_company    100% ████████████████████████ Perfect coverage
phone_1            100% ████████████████████████ Perfect coverage
ship_1             100% ████████████████████████ Perfect coverage
city_record        100% ████████████████████████ Perfect coverage
university_basketb 100% ████████████████████████ Perfect coverage
geo                100% ████████████████████████ Perfect coverage
cre_Doc_Tracking_D 100% ████████████████████████ Perfect coverage
soccer_2           100% ████████████████████████ Perfect coverage
music_4            100% ████████████████████████ Perfect coverage
tracking_grants_fo 100% ████████████████████████ Perfect coverage
company_employee   100% ████████████████████████ Perfect coverage
musical            100% ████████████████████████ Perfect coverage
workshop_paper     100% ████████████████████████ Perfect coverage
cre_Docs_and_Epens 100% ████████████████████████ Perfect coverage
academic           100% ████████████████████████ Perfect coverage
inn_1              100% ████████████████████████ Perfect coverage
storm_record       100% ████████████████████████ Perfect coverage
flight_company     100% ████████████████████████ Perfect coverage
flight_1           100% ████████████████████████ Perfect coverage
customers_card_tra 100% ████████████████████████ Perfect coverage
e_learning         100% ████████████████████████ Perfect coverage
insurance_and_eCla 100% ████████████████████████ Perfect coverage
protein_institute  100% ████████████████████████ Perfect coverage
local_govt_and_lot 100% ████████████████████████ Perfect coverage
cre_Theme_park      93% ██████████████████████   Excellent
sakila_1            93% ██████████████████████   Excellent
behavior_monitorin  90% █████████████████████    Excellent
college_2           90% █████████████████████    Excellent
e_government        90% █████████████████████    Excellent
imdb                87% █████████████████████    Good coverage
customers_and_prod  85% ████████████████████     Good coverage
hr_1                85% ████████████████████     Good coverage
tracking_orders     85% ████████████████████     Good coverage
products_gen_chara  83% ███████████████████      Good coverage
sports_competition  80% ███████████████████      Good coverage
cre_Drama_Workshop  77% ██████████████████       Good coverage
customers_and_invo  77% ██████████████████       Good coverage
customer_deliverie  76% ██████████████████       Good coverage
farm                75% ██████████████████       Good coverage
machine_repair      75% ██████████████████       Good coverage
program_share       75% ██████████████████       Good coverage
customers_campaign  75% ██████████████████       Good coverage
coffee_shop         75% ██████████████████       Good coverage
railway             75% ██████████████████       Good coverage
school_player       75% ██████████████████       Good coverage
chinook_1           72% █████████████████        Moderate - expand
formula_1           69% ████████████████         Moderate - expand
soccer_1            66% ████████████████         Moderate - expand
company_1           66% ████████████████         Moderate - expand
tracking_software_  66% ████████████████         Moderate - expand
baseball_1          50% ████████████             Moderate - expand
solvency_ii         16% ████                     Low - needs work
```
