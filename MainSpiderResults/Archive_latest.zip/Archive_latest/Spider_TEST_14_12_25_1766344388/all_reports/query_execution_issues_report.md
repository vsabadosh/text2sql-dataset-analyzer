# Query Execution Detailed Report

**Generated:** 2025-12-21 20:13:32

## Summary

- **Total Executions:** 2,147 · **Analyzed:** 2,147 · **Skipped:** 0
- **Failures:** 0 (0.0%)

## Failed Items (0)

*No failed executions found.*

## Error Patterns

*No common error patterns detected.*
